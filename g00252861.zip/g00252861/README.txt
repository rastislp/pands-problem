Github link to my project.

https://github.com/rastislp/pands-problem.git
g00252861.py